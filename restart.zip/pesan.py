KURANG_KATA = "Tidak bisa tanpa kata kunci"
TIDAK_ADA = "Salah kata kunci atau barang tidak di temukan😜\n\nUntuk memperbarui data atau bantuan tekan tombol di bawah."
RESPON_TEXT = "CPU : 🟢🔴🟠🟡🔵"
PESAN_HELP = "<b>Cara menggunakan Bot</b>\n \n1.<code> /inout</code> <b>untuk melihat daftar keluar masuk barang</b>, \n\n2.  <code>/stok </code> <i>untuk melihat jumlah stok tanpa duplikat</i> \n\n3. <code>/list </code><b>Untuk melihat daftar harga tanpa terlihat sales dan stok</b>\n\nHappy helping😍😍😝😝",